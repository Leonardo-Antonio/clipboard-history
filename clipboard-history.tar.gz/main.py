from gui import button_icon

if __name__ == "__main__":
    button_icon.run()
